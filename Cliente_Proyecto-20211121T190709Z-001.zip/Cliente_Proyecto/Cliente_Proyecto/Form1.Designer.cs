﻿
namespace Cliente_Proyecto
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.labelConsulta1 = new System.Windows.Forms.Label();
            this.labelCOnsulta2 = new System.Windows.Forms.Label();
            this.labelCOnsulta3 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.textBoxConsulta2 = new System.Windows.Forms.TextBox();
            this.textBoxConsulta3 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.labelconectados = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Jugador = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttoninvitar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(12, 529);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(214, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Selecciona tu consulta:";
            // 
            // labelConsulta1
            // 
            this.labelConsulta1.AutoSize = true;
            this.labelConsulta1.BackColor = System.Drawing.Color.Transparent;
            this.labelConsulta1.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.labelConsulta1.ForeColor = System.Drawing.Color.MediumBlue;
            this.labelConsulta1.Location = new System.Drawing.Point(39, 570);
            this.labelConsulta1.Name = "labelConsulta1";
            this.labelConsulta1.Size = new System.Drawing.Size(336, 17);
            this.labelConsulta1.TabIndex = 6;
            this.labelConsulta1.Text = "Máxima puntuación global y jugador a la que pertenece";
            // 
            // labelCOnsulta2
            // 
            this.labelCOnsulta2.AutoSize = true;
            this.labelCOnsulta2.BackColor = System.Drawing.Color.Transparent;
            this.labelCOnsulta2.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.labelCOnsulta2.ForeColor = System.Drawing.Color.MediumBlue;
            this.labelCOnsulta2.Location = new System.Drawing.Point(39, 605);
            this.labelCOnsulta2.Name = "labelCOnsulta2";
            this.labelCOnsulta2.Size = new System.Drawing.Size(146, 17);
            this.labelCOnsulta2.TabIndex = 7;
            this.labelCOnsulta2.Text = "Puntuación del jugador:";
            // 
            // labelCOnsulta3
            // 
            this.labelCOnsulta3.AutoSize = true;
            this.labelCOnsulta3.BackColor = System.Drawing.Color.Transparent;
            this.labelCOnsulta3.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.labelCOnsulta3.ForeColor = System.Drawing.Color.MediumBlue;
            this.labelCOnsulta3.Location = new System.Drawing.Point(39, 640);
            this.labelCOnsulta3.Name = "labelCOnsulta3";
            this.labelCOnsulta3.Size = new System.Drawing.Size(146, 17);
            this.labelCOnsulta3.TabIndex = 8;
            this.labelCOnsulta3.Text = "Contraseña del usuario:";
            // 
            // radioButton1
            // 
            this.radioButton1.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1.Location = new System.Drawing.Point(12, 568);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(21, 19);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = false;
            // 
            // radioButton2
            // 
            this.radioButton2.Location = new System.Drawing.Point(12, 605);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(21, 19);
            this.radioButton2.TabIndex = 10;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.Location = new System.Drawing.Point(12, 641);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(21, 19);
            this.radioButton3.TabIndex = 11;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "radioButton3";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // textBoxConsulta2
            // 
            this.textBoxConsulta2.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.textBoxConsulta2.Location = new System.Drawing.Point(206, 604);
            this.textBoxConsulta2.Name = "textBoxConsulta2";
            this.textBoxConsulta2.Size = new System.Drawing.Size(100, 23);
            this.textBoxConsulta2.TabIndex = 15;
            this.textBoxConsulta2.Text = "Nombre";
            this.textBoxConsulta2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxConsulta3
            // 
            this.textBoxConsulta3.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.textBoxConsulta3.Location = new System.Drawing.Point(206, 639);
            this.textBoxConsulta3.Name = "textBoxConsulta3";
            this.textBoxConsulta3.Size = new System.Drawing.Size(100, 23);
            this.textBoxConsulta3.TabIndex = 14;
            this.textBoxConsulta3.Text = "Nombre";
            this.textBoxConsulta3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBox1.Location = new System.Drawing.Point(332, 118);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(119, 23);
            this.textBox1.TabIndex = 16;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBox2.Location = new System.Drawing.Point(476, 118);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(119, 23);
            this.textBox2.TabIndex = 17;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelconectados
            // 
            this.labelconectados.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelconectados.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.labelconectados.Location = new System.Drawing.Point(39, 43);
            this.labelconectados.Name = "labelconectados";
            this.labelconectados.Size = new System.Drawing.Size(258, 178);
            this.labelconectados.TabIndex = 23;
            this.labelconectados.Text = "Conéctate para ver los usuarios conectados";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(332, 621);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Enviar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(476, 159);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 26);
            this.button2.TabIndex = 11;
            this.button2.Text = "Conectar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(332, 159);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 26);
            this.button3.TabIndex = 12;
            this.button3.Text = "Desconectar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Underline);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(329, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Regístrate";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(39, 235);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 15);
            this.label3.TabIndex = 28;
            this.label3.Text = "Amigos conectados";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Jugador});
            this.dataGridView1.Location = new System.Drawing.Point(42, 265);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(143, 150);
            this.dataGridView1.TabIndex = 29;
            // 
            // Jugador
            // 
            this.Jugador.HeaderText = "Jugador";
            this.Jugador.Name = "Jugador";
            // 
            // buttoninvitar
            // 
            this.buttoninvitar.Location = new System.Drawing.Point(175, 235);
            this.buttoninvitar.Name = "buttoninvitar";
            this.buttoninvitar.Size = new System.Drawing.Size(75, 23);
            this.buttoninvitar.TabIndex = 30;
            this.buttoninvitar.Text = "Invitar";
            this.buttoninvitar.UseVisualStyleBackColor = true;
            this.buttoninvitar.Click += new System.EventHandler(this.buttoninvitar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(329, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 15);
            this.label4.TabIndex = 31;
            this.label4.Text = "Usuario:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(473, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 15);
            this.label5.TabIndex = 32;
            this.label5.Text = "Contraseña:";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.ForeColor = System.Drawing.Color.LimeGreen;
            this.button4.Location = new System.Drawing.Point(301, 326);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(117, 36);
            this.button4.TabIndex = 33;
            this.button4.Text = "ACEPTAR";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button5.ForeColor = System.Drawing.Color.Red;
            this.button5.Location = new System.Drawing.Point(463, 326);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(117, 36);
            this.button5.TabIndex = 34;
            this.button5.Text = "RECHAZAR";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(627, 473);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttoninvitar);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelconectados);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBoxConsulta3);
            this.Controls.Add(this.textBoxConsulta2);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.labelCOnsulta3);
            this.Controls.Add(this.labelCOnsulta2);
            this.Controls.Add(this.labelConsulta1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelConsulta1;
        private System.Windows.Forms.Label labelCOnsulta2;
        private System.Windows.Forms.Label labelCOnsulta3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.TextBox textBoxConsulta2;
        private System.Windows.Forms.TextBox textBoxConsulta3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label labelconectados;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Jugador;
        private System.Windows.Forms.Button buttoninvitar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}

