﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;


namespace Cliente_Proyecto
{
    public partial class Form1 : Form
    {
        int nForm;
        string Teinvita;
        int id;
        string Tu;
        Socket server;
        Thread atender;
        
        List<Form2> formularios = new List<Form2>();

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false; //Necesario para que los elementos de los formularios puedan ser
            //accedidos desde threads diferentes a los que los crearon
        }

        private void AtenderServidor()
        {
            string lista = null;
            while (true)
            {

                // Recibimos mensaje del servidor  
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                var codigo = Convert.ToInt32(trozos[0]);
                string mensaje= "0";
                
                if (codigo <= 7 || codigo == 8)
                {
                    mensaje = trozos[1].Split('\0')[0];
                }

                int nform;
                switch (codigo)
                {
                    case 0: //desconexión
                        MessageBox.Show(mensaje);
                        break;

                    case 1: //consulta 1

                        MessageBox.Show(mensaje);
                        break;

                    case 2: //consulta 2

                        MessageBox.Show(mensaje);
                        break;

                    case 3: //consulta 3

                        MessageBox.Show(mensaje);
                        break;

                    case 4: //conexión

                        if (Convert.ToString(mensaje) == Convert.ToString(textBox2.Text))
                        {
                            MessageBox.Show("Bienvenido/a " + Convert.ToString(textBox1.Text));
                        }
                        else
                        {
                            MessageBox.Show("Usuario o contraseña erróneos");
                        }

                        break;

                    case 5: //consulta 5
                        MessageBox.Show(mensaje);
                        break;

                    case 6: //notificación
                        lista = null;
                        string[] nombres = mensaje.Split('-');
                        dataGridView1.Rows.Clear();
                        int i = 2;

                        while (i<nombres.Length)
                        {
                            try
                            {
                                nombres[i] = Convert.ToString(nombres[i]).Replace("6", String.Empty);
                                dataGridView1.Rows.Add(Convert.ToString(nombres[i]));
                            }
                            catch
                            { 
                            }
                            lista = lista + Convert.ToString(nombres[i])+ "\n";
                            i = i + 1;
                        }
                        labelconectados.Text = lista;
                        break;

                    case 7: //Abre formulario invitación
                        ThreadStart ts = delegate { ArrancarFormulario(); };
                        Thread T = new Thread(ts);
                        T.Start();
                        // int cont= formularios.Count;
                        //formularios[cont].MostrarInvitacion(mensaje);
                        break;

                    case 8://Acepta o no
                        nform = Convert.ToInt32(trozos[1].Split('\0')[0]);
                        if (trozos[2].Split('\0')[0] == "SI")
                        {
                            MessageBox.Show("Ha aceptado la invitación");
                        }
                        else
                        {
                            MessageBox.Show("Ha rechazado la invitación");
                        }
                        break;
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip del servidor y el puerto del servidor al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9101);
            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectarnos al socket

                //Consultamos los jugadores registrados
                string mensaje = "4/" + textBox1.Text + "/" + textBox2.Text;
                // Enviamos al servidor el nombre introducido
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

            }

            catch (SocketException ex) // Ha habido un error con la conexion
            {
                MessageBox.Show("ERROR: No se ha podido conectar con el servidor");
                return;
            }

            //Necesitamos saber si el usuario es correcto para inciar la conexion
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
            int codigo = Convert.ToInt32(trozos[0]);
            string mensaje2 = trozos[1].Split('\0')[0];
            if (Convert.ToString(mensaje2) == Convert.ToString(textBox2.Text))
            {
                label1.ForeColor = Color.Green;
                textBoxConsulta2.ForeColor = Color.Black;
                textBoxConsulta3.ForeColor = Color.Black;

                MessageBox.Show("Bienvenido/a " + Convert.ToString(textBox1.Text));
                //pongo en marcha el thread que atenderá los mensajes del servidor
                ThreadStart ts = delegate { AtenderServidor(); };
                atender = new Thread(ts);
                atender.Start();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña erróneos");

                //Mensaje de desconectar
                string mensaje = "0/";
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                //Cerramos la conexion
                server.Send(msg);

                server.Shutdown(SocketShutdown.Both);
                server.Close();
            }
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                //Mensaje de desconectar
                string mensaje = "0/";

                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                // FIN del servicio, nos desconectamos del servidor

                atender.Abort();

                labelconectados.Text = ("Conéctate para ver los usuarios conectados");
                dataGridView1.Rows.Clear();
                label1.ForeColor = Color.AliceBlue;
                textBoxConsulta2.ForeColor = Color.Gray;
                textBoxConsulta3.ForeColor = Color.Gray;
                server.Shutdown(SocketShutdown.Both);
                server.Close();
            }
            catch
            {
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButton1.Checked) //RadioButton de la máxima puntuación y jugador que la tiene
                {
                    string mensaje = "1/" + textBoxConsulta2.Text + "/" + textBoxConsulta3.Text;
                    // Enviamos al servidor el nombre introducido
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                }

                else if (radioButton2.Checked) //RadioButton de la puntuación del jugador 'X'
                {
                    string mensaje = "2/" + textBoxConsulta2.Text + "/" + textBoxConsulta3.Text;
                    // Enviamos al servidor el nombre introducido
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                }

                else if (radioButton3.Checked) //RadioButton de la contraseña del jugador 'X'
                {
                    string mensaje = "3/" + textBoxConsulta3.Text + "/" + textBoxConsulta2.Text;
                    // Enviamos al servidor el nombre introducido
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);

                }

                else
                {
                    MessageBox.Show("Se ha conectado con el servidor pero no hay ninguna solicitud que hacerle");
                }
            }
            catch
            {
                MessageBox.Show("Porfavor autentifícate para poder acceder a las consultas");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //Creamos un IPEndPoint con el ip del servidor y el puerto del servidor al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9101);


            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectarnos al socket

                string mensaje = "5/" + textBox1.Text + "/" + textBox2.Text;
                // Enviamos al servidor el nombre introducido
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            catch (SocketException ex) // Ha habido un error con la conexion
            {
                MessageBox.Show("ERROR: No se ha podido conectar con el servidor");
                return;
            }

            //Mensaje de desconectar
            //string mensaje3 = "0/";

            //byte[] msg3 = System.Text.Encoding.ASCII.GetBytes(mensaje3);
            //server.Send(msg3);

            // Recibimos la respuesta por parte del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            string mensaje2 = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje2);

            // FIN del servicio, nos desconectamos del servidor
            label1.ForeColor = Color.AliceBlue;
            textBoxConsulta2.ForeColor = Color.Gray;
            textBoxConsulta3.ForeColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }

        private void ArrancarFormulario()
        {
            int cont = formularios.Count;
            Form2 f = new Form2(cont, server);
            formularios.Add(f);
            f.ShowDialog();
            
        }

        private void buttoninvitar_Click(object sender, EventArgs e)
        {
            string invitados = null;
            int i = 0;
            bool invito = true;
            int numinvitados = dataGridView1.SelectedCells.Count;
            while (i < dataGridView1.Rows.Count)
            {
                if (dataGridView1.Rows[i].Cells[0].Selected)
                {
                    if (dataGridView1.Rows[i].Cells[0].Value == null)
                    {
                        MessageBox.Show("Tienes que seleccionar un jugador existente, no puedes invitar a una casilla en blanco.");
                        invito = false;
                        break;
                    }
                    else if (dataGridView1.Rows[i].Cells[0].Value.ToString() == textBox1.Text)
                    {
                        MessageBox.Show("Te estás invitando a ti mismo, intenta invitar a otros jugadores.");
                        invito = false;
                        break;
                    }
                    else
                    {
                        invitados = invitados + "/";
                        invitados = invitados + dataGridView1.Rows[i].Cells[0].Value.ToString();
                        i = i + 1;
                    }
                }
                else
                {
                    i = i + 1;
                }

            }

            if (invito == true)
            {
                string mensaje = "7/" + textBox1.Text + "/" + Convert.ToString(numinvitados) + invitados;
                // Enviamos al servidor el nombre introducido
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                MessageBox.Show("Has invitado a los jugadores");
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/1";
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Cambios estéticos en el formulario
            button4.Enabled = false;
            button4.Visible = false;
            button5.Enabled = false;
            button5.Visible = false;

            label4.Enabled = false;
            label4.Visible = false;
            label5.Enabled = false;
            label5.Visible = false;

            //pictureBox17.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/0";
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            this.Close();
        }
    }
}


    



//    string mensaje = "7/" + textBox1.Text + "/2/PAULA";
//    // Enviamos al servidor el nombre introducido
//    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
//    server.Send(msg);