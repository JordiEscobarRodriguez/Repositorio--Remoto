﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Media;

namespace Cliente_Proyecto
{
    public partial class Form3 : Form
    {
        int nForm;
        string host;
        Socket server;
        string Teinvita;
        int id;
        string Tu;
        int tiempoinvitacion = 15;

        
        public Form3(int nForm, Socket server)
        {
            InitializeComponent();
            this.nForm = nForm;
            this.server = server;
        }

        public void MostrarInvitacion(string mensaje, string usuario)
        {
            string[] nombres = mensaje.Split('-');
            Teinvita = nombres[0];
            id = Convert.ToInt32(nombres[1]);
            Tu = usuario;
            label4.Text = ("Te está incitando " + nombres[0] + " al chat número " + nombres[1]);
        }

        public void SoyHost(string host)
        {
            this.host = host;
        }

        public void ActualizaChat(string chat)
        {
            richTextBox1.Text = chat;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            

            if (host != Teinvita)
            {
                // Marcamos un tiempo de vida de la invitación
                label5.Text = Convert.ToString(tiempoinvitacion);
                label6.Text = ("Invitado");
                timer1.Start();
            }
            else
            {
                // Cambios estéticos en el formulario
                botonAceptar.Enabled = false;
                botonAceptar.Visible = false;
                botonRechazar.Enabled = false;
                botonRechazar.Visible = false;

                label4.Enabled = false;
                label4.Visible = false;
                label5.Enabled = false;
                label5.Visible = false;

                

                label6.Text = ("Anfitrión");
            }

            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (tiempoinvitacion == 0)
            {
                timer1.Stop();
                string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/0";
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                this.Close();
            }
            else
            {
                tiempoinvitacion = tiempoinvitacion - 1;
                label5.Text = Convert.ToString(tiempoinvitacion);
            }
        }

        private void botonAceptar_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/1";
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Cambios estéticos en el formulario
            botonAceptar.Enabled = false;
            botonAceptar.Visible = false;
            botonRechazar.Enabled = false;
            botonRechazar.Visible = false;

            label4.Enabled = false;
            label4.Visible = false;
            label5.Enabled = false;
            label5.Visible = false;

           
        }

        private void botonRechazar_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            string mensaje = "8/" + nForm + "/" + Teinvita + "/" + Tu + "/" + id + "/0";
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mensaje = "9/" + nForm + "/" + textBox1.Text + "/" + Tu + "/" + id;
            // Enviamos al servidor el mensaje
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
            textBox1.Clear();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                e.Handled = true;
                string mensaje = "9/" + nForm + "/" + textBox1.Text + "/" + Tu + "/" + id;
                // Enviamos al servidor el mensaje
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
                textBox1.Clear();
                
            }
        }
    }
}
